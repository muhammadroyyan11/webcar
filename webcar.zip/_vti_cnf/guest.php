vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|30 Jun 2006 10:04:23 -0000
vti_extenderversion:SR|4.0.2.7802
