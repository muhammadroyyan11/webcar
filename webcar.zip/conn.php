<?php
$connection = mysql_connect("localhost", "root", "") or die(mysql_errno() . ": " . mysql_error() . "<br>");
mysql_select_db("dbWebcar", $connection) or die(mysql_errno() . ": " . mysql_error() . "<br>");
?>

