<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.style1 {font-size: smaller}
-->
</style>
</head>

<body>

<script language="javascript" type="text/javascript" src="js/datetimepicker.js">

//Date Time Picker script- by TengYong Ng of http://www.rainforestnet.com
//Script featured on JavaScript Kit (http://www.javascriptkit.com)
//For this script, visit http://www.javascriptkit.com

</script>

<form name="form1" method="post" action="">
  <table width="100%"  border="1">
   
    <tr>
      <th width="22%" scope="row"><span class="style1">Verification Date </span></th>
      <td width="2%">:</td>
      <td class="t1"><input id="demo1" type="text" size="25"><a href="javascript:NewCal('demo1','yyyymmdd')"><img src="cal.gif" width="16" height="16" border="0" alt="Pick a date"></a></td>
    </tr>
    <tr>
      <th height="241" scope="row"><span class="style1">Comment</span></th>
      <td>:</td>
      <td class="t1" ><textarea name="textarea" cols="100" rows="15"></textarea></td>
    </tr>
    <tr>
      <th colspan="3" scope="row"><div align="left">
        <input type="submit" name="Submit" value="Save">
        <input type="submit" name="Submit2" value="Delete">
        <input type="submit" name="Submit3" value="Exit">
      </div></th>
    </tr>
  </table>
</form>
</body>
</html>
